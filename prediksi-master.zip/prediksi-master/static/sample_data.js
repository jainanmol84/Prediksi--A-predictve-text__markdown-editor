collection = [
'popuplate',
'me',
'with',
'data',
'support',
'vector',
'machine',
'algorithm',
'and',
'for',
'this',
'is',
];
